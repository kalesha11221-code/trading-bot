import os
import db_helper
import time
import ml_brain
import json

import urllib.request
import threading
import pandas as pd
import numpy as np
from datetime import datetime, timezone, timedelta
IST = timezone(timedelta(hours=5, minutes=30))

def get_ist_now():
    """Returns current datetime in Indian Standard Time (IST)."""
    return datetime.now(IST)

# --- CONFIGURATION (Expanded Top Liquid Crypto Universe) ---
FUTURES_SYMBOLS = [
    "BTC-USD", "ETH-USD", "SOL-USD", "BNB-USD", "DOGE-USD", "XRP-USD",
    "SUI-USD", "AVAX-USD", "LINK-USD", "NEAR-USD", "ADA-USD", "PEPE-USD",
    "APT-USD", "FET-USD", "RENDER-USD"
]
LEVERAGE = 5
MARGIN_PER_TRADE = 5000.0  # ₹5000 per trade margin
MAX_POSITIONS = 4
USD_TO_INR = 84.5

STATE_FILE = 'fo_state.json'
LOG_FILE = 'fo_trades_log.csv'

file_lock = threading.Lock()

def init_files():
    with file_lock:
        if not os.path.exists(STATE_FILE):
            with open(STATE_FILE, 'w') as f:
                json.dump({}, f)
        # Restore full trade history from MongoDB Cloud so restarts never lose history
        db_helper.sync_cloud_to_local(is_futures=True)
        if not os.path.exists(LOG_FILE):
            with open(LOG_FILE, 'w') as f:
                f.write("Timestamp,Symbol,Action,Side,EntryPrice,ExitPrice,Margin,Leverage,Profit_INR\n")

def get_state():
    return db_helper.get_state('fo_state')

def save_state(state):
    db_helper.save_state('fo_state', state)

def log_trade(sym, action, side, entry_p, exit_p, margin, lev, profit):
    with file_lock:
        timestamp = get_ist_now().strftime('%Y-%m-%d %H:%M:%S')
        trade_data = {
            'Timestamp': timestamp,
            'Symbol': sym,
            'Action': action,
            'Side': side,
            'EntryPrice': entry_p,
            'ExitPrice': exit_p,
            'Margin': margin,
            'Leverage': lev,
            'Profit_INR': profit
        }
        db_helper.log_trade_persistent(trade_data, is_futures=True)

# -------------------------------------------------------------
# 🎯 OPTION 1: DAILY TARGET (+₹1,800) & MAX LOSS (-₹1,000) GUARD
# -------------------------------------------------------------
DAILY_PROFIT_TARGET_INR = 1800.0   # Lock day's profits when +₹1,800 is hit
DAILY_MAX_LOSS_INR = -1000.0       # Halt new entries for the day if -₹1,000 is hit

def get_today_realized_pnl():
    """Calculates today's total realized PnL across Spot & Futures in INR (IST day)."""
    today_str = get_ist_now().strftime('%Y-%m-%d')
    total_pnl_inr = 0.0
    
    # 1. Spot / Stock trades (trades_log.csv)
    if os.path.exists('trades_log.csv'):
        try:
            df_spot = pd.read_csv('trades_log.csv')
            if not df_spot.empty and 'Time' in df_spot.columns and 'Action' in df_spot.columns and 'Profit' in df_spot.columns:
                sells = df_spot[df_spot['Action'].str.upper() == 'SELL']
                for _, r in sells.iterrows():
                    t_val = str(r['Time'])
                    if t_val.startswith(today_str):
                        p_val = str(r['Profit']).replace('₹', '').replace(',', '').strip()
                        if p_val and p_val != '-':
                            p_float = float(p_val)
                            sym = str(r.get('Symbol', ''))
                            if sym.endswith('-USD'):
                                total_pnl_inr += p_float * USD_TO_INR
                            else:
                                total_pnl_inr += p_float
        except Exception:
            pass

    # 2. Futures trades (fo_trades_log.csv)
    if os.path.exists('fo_trades_log.csv'):
        try:
            df_fo = pd.read_csv('fo_trades_log.csv')
            if not df_fo.empty and 'Timestamp' in df_fo.columns and 'Action' in df_fo.columns and 'Profit_INR' in df_fo.columns:
                closes = df_fo[df_fo['Action'].str.upper() == 'CLOSE']
                for _, r in closes.iterrows():
                    t_val = str(r['Timestamp'])
                    if t_val.startswith(today_str):
                        p_val = str(r['Profit_INR']).replace('₹', '').replace(',', '').strip()
                        if p_val and p_val != '-':
                            total_pnl_inr += float(p_val)
        except Exception:
            pass

    return round(total_pnl_inr, 2)

def check_daily_guard():
    """
    Returns (is_locked: bool, status_reason: str, today_pnl: float)
    - If today_pnl >= DAILY_PROFIT_TARGET_INR: Locks profits, pauses new entries.
    - If today_pnl <= DAILY_MAX_LOSS_INR: Guard triggered, halts new entries.
    - Otherwise: Active trading permitted.
    """
    today_pnl = get_today_realized_pnl()
    if today_pnl >= DAILY_PROFIT_TARGET_INR:
        return True, f"🎯 DAILY PROFIT TARGET LOCKED (+₹{today_pnl:,.2f} >= ₹{DAILY_PROFIT_TARGET_INR:,.2f})! Day's profit secured.", today_pnl
    if today_pnl <= DAILY_MAX_LOSS_INR:
        return True, f"🛑 DAILY MAX LOSS GUARD TRIGGERED (₹{today_pnl:,.2f} <= ₹{DAILY_MAX_LOSS_INR:,.2f})! Preserving capital.", today_pnl
    return False, f"ACTIVE (Today PnL: ₹{today_pnl:,.2f})", today_pnl

# -------------------------------------------------------------
# ⏰ OPTION 2: MARKET PEAK HOURS TIMING MULTIPLIER
# -------------------------------------------------------------
def get_market_session_multiplier(is_crypto=True):
    """
    Dynamically scales trade size during high-liquidity sessions:
    - Crypto US Session (18:30 - 23:59 IST): 1.30x
    - Crypto Asian Session (05:30 - 09:30 IST): 1.15x
    - Off-peak: 1.0x
    """
    now = get_ist_now()
    curr_t = now.time()
    t_us_start = datetime.strptime("18:30", "%H:%M").time()
    t_us_end = datetime.strptime("23:59", "%H:%M").time()
    t_asia_start = datetime.strptime("05:30", "%H:%M").time()
    t_asia_end = datetime.strptime("09:30", "%H:%M").time()
    
    if t_us_start <= curr_t <= t_us_end:
        return 1.30, "US Peak Session (1.30x)"
    elif t_asia_start <= curr_t <= t_asia_end:
        return 1.15, "Asian Open Session (1.15x)"
    return 1.0, "Standard Crypto Session (1.0x)"

# -------------------------------------------------------------
# 🌊 OPTION 3: MARKET REGIME DETECTION (TREND vs CHOPPY RANGE)
# -------------------------------------------------------------
def detect_market_regime(df):
    """
    Detects whether asset is 'TRENDING' or in a sideways 'RANGE'.
    Uses Bollinger Bandwidth + EMA 9 vs 21 spread.
    """
    if df is None or len(df) < 20:
        return "TRENDING", 1.0, "Trend Momentum"
        
    close = df['close']
    sma_20 = close.rolling(window=20).mean()
    std_20 = close.rolling(window=20).std()
    upper_b = sma_20 + (std_20 * 2)
    lower_b = sma_20 - (std_20 * 2)
    
    last_close = close.iloc[-1]
    last_sma = sma_20.iloc[-1] if not pd.isna(sma_20.iloc[-1]) else last_close
    bandwidth = ((upper_b.iloc[-1] - lower_b.iloc[-1]) / last_sma) * 100.0 if last_sma > 0 else 2.0
    
    ema_9 = close.ewm(span=9, adjust=False).mean().iloc[-1]
    ema_21 = close.ewm(span=21, adjust=False).mean().iloc[-1]
    ema_spread_pct = (abs(ema_9 - ema_21) / last_close) * 100.0 if last_close > 0 else 0.5
    
    if bandwidth < 2.2 and ema_spread_pct < 0.25:
        return "RANGE", bandwidth, "Sideways Range-Bound"
    else:
        return "TRENDING", bandwidth, "Trending Momentum"

# -------------------------------------------------------------
# ⚡ OPTION 4: WINNING STREAK DYNAMIC COMPOUNDING
# -------------------------------------------------------------
def get_win_streak_multiplier():
    """
    Consecutive wins scale trade size (+10% to +25%).
    Any loss immediately resets streak multiplier to 1.0x (Risk Shield).
    """
    streak = 0
    mult = 1.0
    if os.path.exists('fo_trades_log.csv'):
        try:
            df = pd.read_csv('fo_trades_log.csv')
            if not df.empty and 'Action' in df.columns and 'Profit_INR' in df.columns:
                closes = df[df['Action'].str.upper() == 'CLOSE']
                if not closes.empty:
                    for i in range(len(closes) - 1, -1, -1):
                        p_val = str(closes.iloc[i]['Profit_INR']).replace('₹', '').replace(',', '').strip()
                        if p_val and p_val != '-':
                            p_num = float(p_val)
                            if p_num > 0:
                                streak += 1
                            else:
                                break
        except Exception:
            pass

    if streak >= 4:
        mult = 1.25
    elif streak == 3:
        mult = 1.20
    elif streak == 2:
        mult = 1.10
    else:
        mult = 1.00
        
    return mult, streak

def fetch_binance_data(sym):
    # 1. Try Binance Direct API
    try:
        coin = sym.replace('-USD', '')
        binance_pair = f'{coin}USDT'
        url = f'https://api.binance.com/api/v3/klines?symbol={binance_pair}&interval=5m&limit=100'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read().decode())
            rows = []
            for k in data:
                rows.append({
                    'timestamp': datetime.fromtimestamp(k[0] / 1000.0),
                    'open': float(k[1]), 'high': float(k[2]),
                    'low': float(k[3]), 'close': float(k[4]), 'volume': float(k[5])
                })
            df = pd.DataFrame(rows)
            if not df.empty and len(df) >= 30:
                return df
    except Exception:
        pass

    # 2. Cloud Fallback: Yahoo v8 Direct Chart API (Bypasses all Geo-Blocks & Cloud Bans!)
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Accept': 'application/json'
        }
        url = f'https://query1.finance.yahoo.com/v8/finance/chart/{sym}?interval=5m&range=1d'
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=4) as resp:
            res = json.loads(resp.read().decode())
            chart = res['chart']['result'][0]
            timestamps = chart.get('timestamp', [])
            quote = chart['indicators']['quote'][0]
            if timestamps and 'close' in quote:
                rows = []
                for i in range(len(timestamps)):
                    c = quote['close'][i]
                    if c is not None:
                        rows.append({
                            'timestamp': datetime.fromtimestamp(timestamps[i]),
                            'open': float(quote.get('open', [c])[i] or c),
                            'high': float(quote.get('high', [c])[i] or c),
                            'low': float(quote.get('low', [c])[i] or c),
                            'close': float(c),
                            'volume': float(quote.get('volume', [100.0])[i] or 100.0)
                        })
                df = pd.DataFrame(rows)
                if not df.empty and len(df) >= 30:
                    return df
    except Exception:
        pass

    return pd.DataFrame()

def generate_futures_signal(df, sym="BTC-USD"):
    if df.empty or len(df) < 30: return 'HOLD', 0.0
    
    df['EMA_9'] = df['close'].ewm(span=9, adjust=False).mean()
    df['EMA_21'] = df['close'].ewm(span=21, adjust=False).mean()
    df['EMA_50'] = df['close'].ewm(span=50, adjust=False).mean()
    
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.where(delta < 0, 0)).ewm(alpha=1/14, adjust=False).mean()
    rs = gain / (loss + 1e-9)
    df['RSI'] = 100 - (100 / (1 + rs))
    
    last = df.iloc[-1]
    prev = df.iloc[-2]
    
    # 🏛️ Institutional Confluence: Consult ml_brain (SMC + Machine Learning)
    ml_sig = ml_brain.get_ml_signal(sym)
    smc_info = ml_brain.get_smc_analysis(sym)
    smc_bias = smc_info.get("bias", "NEUTRAL")
    
    # Candlestick Confirmation Guard
    is_candle_bullish = (last['close'] >= last['open']) or (last['close'] >= prev['close'])
    is_candle_bearish = (last['close'] <= last['open']) or (last['close'] <= prev['close'])
    
    # 🟢 INSTITUTIONAL BULLISH ENTRY (LONG 5x)
    # EMA 9 > 21 + RSI momentum + ML == 1 + (SMC Bullish or Neutral) + Bullish Candle
    if last['EMA_9'] > last['EMA_21'] and last['RSI'] < 72 and is_candle_bullish:
        if (last['close'] > last['EMA_50'] or (prev['RSI'] <= 45 and last['RSI'] > prev['RSI'])):
            if ml_sig == 1 and smc_bias != "BEARISH":
                return 'LONG', last['close']
                
    # 🔴 INSTITUTIONAL BEARISH ENTRY (SHORT 5x)
    # EMA 9 < 21 + RSI dropping + ML == 0 + (SMC Bearish or Neutral) + Bearish Candle
    if last['EMA_9'] < last['EMA_21'] and last['RSI'] > 28 and is_candle_bearish:
        if (last['close'] < last['EMA_50'] or (prev['RSI'] >= 55 and last['RSI'] < prev['RSI'])):
            if ml_sig == 0 and smc_bias != "BULLISH":
                return 'SHORT', last['close']
            
    return 'HOLD', last['close']

def run_futures_bot():
    init_files()
    cooldown_dict = {}
    print("🚀 Institutional Futures Paper Bot Started (Leverage: 5x | SMC & Trailing Engine)", flush=True)
    
    while True:
        try:
            state = get_state()
            open_symbols = list(state.keys())
            
            for sym in FUTURES_SYMBOLS:
                df = fetch_binance_data(sym)
                if df.empty: continue
                
                signal, current_price = generate_futures_signal(df, sym)
                
                if sym in state:
                    pos = state[sym]
                    side = pos['side']
                    entry = pos['entry_price']
                    qty = pos['qty']
                    margin = float(pos['margin'])
                    
                    if side == 'LONG':
                        pnl_usd = (current_price - entry) * qty
                    else: 
                        pnl_usd = (entry - current_price) * qty
                        
                    pnl_inr = pnl_usd * USD_TO_INR
                    roe_pct = (pnl_inr / margin) * 100.0

                    # 🏛️ INSTITUTIONAL FEE-AWARE P&L ENGINE
                    # Margin: ₹5,000 | Leverage: 5x | Notional: ₹25,000
                    # Roundtrip Taker Fee: 0.10% on ₹25,000 = ₹25.00 (0.50% ROE)
                    fee_inr = margin * LEVERAGE * 0.001  # Exact ₹25 roundtrip fee
                    net_pnl_inr = pnl_inr - fee_inr
                    net_roe_pct = (net_pnl_inr / margin) * 100.0

                    # Track Peak ROE for trailing profit
                    peak_roe = max(pos.get('peak_roe', 0.0), roe_pct)
                    pos['peak_roe'] = peak_roe
                    save_state(state)
                    
                    # 🧠 AUTONOMOUS AI FUTURES PROFIT HARVESTER
                    # The AI autonomously detects momentum exhaustion, trailing peaks, and candle reversals!
                    last_c = df.iloc[-1]
                    prev_c = df.iloc[-2]
                    
                    # 🌊 OPTION 3: Market Regime Detection
                    regime, bandwidth_val, regime_desc = detect_market_regime(df)
                    target_roe = 2.2 if regime == "RANGE" else 3.5

                    # Check if momentum is stalling or reversing on the latest 5m candle
                    if side == 'LONG':
                        is_exhaustion = (last_c['close'] < last_c['open']) or (last_c['RSI'] < prev_c['RSI'] and last_c['RSI'] > 60)
                    else: # SHORT
                        is_exhaustion = (last_c['close'] > last_c['open']) or (last_c['RSI'] > prev_c['RSI'] and last_c['RSI'] < 40)
                    
                    should_close = False
                    reason = ""
                    
                    # 1. 🧠 AI Momentum Exhaustion Harvest: Once in profit (ROE >= +2.0%), if candle momentum stalls, take profit immediately!
                    if roe_pct >= 2.0 and is_exhaustion:
                        should_close = True
                        reason = f"🧠 AI_AUTONOMOUS_HARVEST (+{roe_pct:.2f}% ROE | Net: +₹{net_pnl_inr:.2f})"
                    
                    # 2. 🛡️ Dynamic Trailing Profit Lock: Once peak hits +2.0%, locks win if dips 0.6% from high
                    elif peak_roe >= 2.0 and roe_pct <= (peak_roe - 0.6):
                        should_close = True
                        reason = f"DYNAMIC_TRAILING_LOCK (Peak: +{peak_roe:.1f}%, Net: +₹{net_pnl_inr:.2f})"
                        
                    # 3. 🎯 Scalp Target (Adaptive to Regime: 2.2% Range | 3.5% Trend)
                    elif roe_pct >= target_roe:
                        should_close = True
                        reason = f"TARGET_PROFIT_AUTO ({regime} +{roe_pct:.2f}% ROE | Net: +₹{net_pnl_inr:.2f})"
                        
                    # 4. 🔒 Zero-Loss Breakeven Lock: If peaked >= +1.8%, exit if drops to <= +0.8%
                    elif peak_roe >= 1.8 and roe_pct <= 0.8:
                        should_close = True
                        reason = f"ZERO_LOSS_BREAKEVEN (+0.8% ROE | Net: +₹{net_pnl_inr:.2f})"
                        
                    # 5. 🔄 Autonomous Reversal Exit (Opposing signal and ROE >= +1.0%)
                    elif (side == 'LONG' and signal == 'SHORT' and roe_pct >= 1.0) or (side == 'SHORT' and signal == 'LONG' and roe_pct >= 1.0):
                        should_close = True
                        reason = f"REVERSAL_AUTO_EXIT (Net: +₹{net_pnl_inr:.2f})"
                        
                    # 6. 🛑 Strict Risk Guard / Stop Loss (-2.5% ROE = ₹125 max loss)
                    elif roe_pct <= -2.5:
                        should_close = True
                        reason = f"CAPITAL_GUARD_STOP_LOSS (-2.5% ROE | Capital Protected)"
                        
                    if should_close:
                        log_trade(sym, "CLOSE", side, entry, current_price, margin, LEVERAGE, round(pnl_inr, 2))
                        del state[sym]
                        save_state(state)
                        cooldown_dict[sym] = time.time() + 300
                        print(f"[{get_ist_now().strftime('%H:%M:%S IST')}] 🛑 CLOSED {side} {sym} | PnL: ₹{pnl_inr:.2f} ({reason})", flush=True)
                        time.sleep(2)
                        
                elif len(state) < MAX_POSITIONS and signal != 'HOLD':
                    if time.time() < cooldown_dict.get(sym, 0):
                        continue

                    # 🎯 OPTION 1: Daily Target (+₹1,800) & Max Loss (-₹1,000) Guard
                    is_daily_locked, daily_guard_reason, today_pnl = check_daily_guard()
                    if is_daily_locked:
                        continue

                    # ⚡ OPTION 2 & OPTION 4: Session Timing & Win Streak Compounding Sizing
                    session_mult, session_name = get_market_session_multiplier(is_crypto=True)
                    streak_mult, win_streak = get_win_streak_multiplier()
                    combo_mult = min(1.50, round(session_mult * streak_mult, 2))
                    trade_margin = round(MARGIN_PER_TRADE * combo_mult, 2)
                    
                    qty_usd = (trade_margin / USD_TO_INR) * LEVERAGE
                    coin_qty = qty_usd / current_price
                    
                    state[sym] = {
                        "side": signal,
                        "entry_price": current_price,
                        "qty": coin_qty,
                        "margin": trade_margin,
                        "leverage": LEVERAGE,
                        "peak_roe": 0.0,
                        "timestamp": get_ist_now().strftime('%Y-%m-%d %H:%M:%S')
                    }
                    save_state(state)
                    log_trade(sym, "OPEN", signal, current_price, 0, trade_margin, LEVERAGE, 0.0)
                    regime, _, _ = detect_market_regime(df)
                    print(f"[{get_ist_now().strftime('%H:%M:%S IST')}] 🏛️ OPENED {signal} {sym} @ ${current_price:.2f} [{session_name} | {regime} | Margin: ₹{trade_margin:,.0f} ({combo_mult:.2f}x)]", flush=True)
                    time.sleep(2)
                    
            time.sleep(10) 
            
        except Exception as e:
            print(f"Futures Bot Error: {e}")
            time.sleep(10)

if __name__ == "__main__":
    run_futures_bot()
